<?php
function test()
{
	echo __FILE__."\n";
}
